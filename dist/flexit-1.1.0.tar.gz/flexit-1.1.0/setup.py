# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flexit']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy-Utils>=0.38.2,<0.39.0',
 'SQLAlchemy>=1.4.31,<2.0.0',
 'dateparser>=1.1.0,<2.0.0',
 'psycopg2>=2.9.3,<3.0.0',
 'pydantic>=1.9.0,<2.0.0',
 'python-decouple>=3.6,<4.0']

setup_kwargs = {
    'name': 'flexit',
    'version': '1.1.0',
    'description': '',
    'long_description': None,
    'author': 'Andrew Loutfi',
    'author_email': 'aloutfi@umn.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
